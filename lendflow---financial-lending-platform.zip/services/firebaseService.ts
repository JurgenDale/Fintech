
import { Loan, LoanStatus, Repayment, Role, User } from '../types';

// --- MOCK DATA ---
export const users: User[] = [
  { id: 'user-admin-1', name: 'Alice Admin', email: 'alice@lendflow.com', role: Role.Admin },
  { id: 'user-lender-1', name: 'Bob Lender', email: 'bob@lendflow.com', role: Role.Lender },
  { id: 'user-borrower-1', name: 'Charlie Customer', email: 'charlie@lendflow.com', role: Role.Borrower },
  { id: 'user-borrower-2', name: 'Diana Debtor', email: 'diana@lendflow.com', role: Role.Borrower },
];

let loans: Loan[] = [
    {
        id: 'loan-1',
        borrowerId: 'user-borrower-1',
        borrowerName: 'Charlie Customer',
        amountRequested: 10000,
        amountApproved: 10000,
        purpose: 'Home Improvement',
        repaymentPeriod: 12,
        interestRate: 5,
        status: LoanStatus.Disbursed,
        applicationDate: new Date('2023-10-01T10:00:00Z').toISOString(),
        approvalDate: new Date('2023-10-02T14:00:00Z').toISOString(),
        disbursementDate: new Date('2023-10-05T11:00:00Z').toISOString(),
        repaymentSchedule: Array.from({ length: 12 }).map((_, i) => ({
            dueDate: new Date(2023, 10 + i, 5).toISOString(),
            amountDue: 856.07,
            status: new Date() > new Date(2023, 10 + i, 5) ? 'Paid' : 'Pending',
        })),
        lenderId: 'user-lender-1',
    },
    {
        id: 'loan-2',
        borrowerId: 'user-borrower-2',
        borrowerName: 'Diana Debtor',
        amountRequested: 25000,
        amountApproved: 25000,
        purpose: 'Car Purchase',
        repaymentPeriod: 36,
        interestRate: 7.5,
        status: LoanStatus.Paid,
        applicationDate: new Date('2022-01-15T09:00:00Z').toISOString(),
        approvalDate: new Date('2022-01-16T17:00:00Z').toISOString(),
        disbursementDate: new Date('2022-01-20T10:00:00Z').toISOString(),
        repaymentSchedule: Array.from({ length: 36 }).map((_, i) => ({
            dueDate: new Date(2022, 1 + i, 20).toISOString(),
            amountDue: 777.89,
            status: 'Paid',
        })),
        lenderId: 'user-lender-1',
    },
    {
        id: 'loan-3',
        borrowerId: 'user-borrower-1',
        borrowerName: 'Charlie Customer',
        amountRequested: 5000,
        purpose: 'Vacation',
        repaymentPeriod: 6,
        status: LoanStatus.Pending,
        applicationDate: new Date().toISOString(),
    },
     {
        id: 'loan-4',
        borrowerId: 'user-borrower-2',
        borrowerName: 'Diana Debtor',
        amountRequested: 15000,
        amountApproved: 12000,
        purpose: 'Business Startup',
        repaymentPeriod: 24,
        interestRate: 8,
        status: LoanStatus.Approved,
        applicationDate: new Date('2024-03-20T12:00:00Z').toISOString(),
        approvalDate: new Date('2024-03-22T16:00:00Z').toISOString(),
        lenderId: 'user-lender-1',
    },
];

let repayments: Repayment[] = [];

// --- MOCK API FUNCTIONS ---

const simulateDelay = <T,>(data: T, ms = 500): Promise<T> =>
  new Promise(resolve => setTimeout(() => resolve(JSON.parse(JSON.stringify(data))), ms));


export const getLoans = async (): Promise<Loan[]> => {
    return simulateDelay(loans);
};

export const addLoan = async (loanData: Omit<Loan, 'id' | 'status' | 'applicationDate' | 'borrowerName'>, borrower: User): Promise<Loan> => {
    const newLoan: Loan = {
        id: `loan-${Date.now()}`,
        status: LoanStatus.Pending,
        applicationDate: new Date().toISOString(),
        borrowerName: borrower.name,
        ...loanData
    };
    loans.push(newLoan);
    return simulateDelay(newLoan);
};

export const updateLoan = async (loanId: string, updates: Partial<Loan>): Promise<Loan> => {
    let targetLoan: Loan | undefined;
    loans = loans.map(loan => {
        if (loan.id === loanId) {
            targetLoan = { ...loan, ...updates };
            return targetLoan;
        }
        return loan;
    });
    if (!targetLoan) throw new Error("Loan not found");

    if (updates.status === LoanStatus.Approved && targetLoan.amountApproved && targetLoan.interestRate && targetLoan.repaymentPeriod) {
       // Simple interest calculation for monthly payments
        const principal = targetLoan.amountApproved;
        const annualRate = targetLoan.interestRate / 100;
        const monthlyRate = annualRate / 12;
        const numPayments = targetLoan.repaymentPeriod;

        const monthlyPayment = (principal * monthlyRate * Math.pow(1 + monthlyRate, numPayments)) / (Math.pow(1 + monthlyRate, numPayments) - 1);
        
        targetLoan.repaymentSchedule = Array.from({ length: numPayments }).map((_, i) => ({
            dueDate: new Date(new Date().setMonth(new Date().getMonth() + i + 1)).toISOString(),
            amountDue: parseFloat(monthlyPayment.toFixed(2)),
            status: 'Pending',
        }));
    }

    return simulateDelay(targetLoan);
};
