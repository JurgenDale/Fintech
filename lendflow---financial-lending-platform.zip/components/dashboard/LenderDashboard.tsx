
import React, { useEffect, useState } from 'react';
import { getLoans } from '../../services/firebaseService';
import { Loan } from '../../types';
import { useAuth } from '../../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../ui/Card';
import LoadingSpinner from '../shared/LoadingSpinner';
import { formatCurrency } from '../../lib/utils';
import LoanList from '../loans/LoanList';
import { DollarSign, FileText, PiggyBank } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';


interface LenderStats {
  activeLoansCount: number;
  totalDisbursed: number;
  totalRepaid: number;
  statusDistribution: {name: string, value: number}[];
}

const COLORS = {
    'Disbursed': '#3b82f6',
    'Paid': '#22c55e',
    'Overdue': '#f97316',
    'Approved': '#8b5cf6',
};

const LenderDashboard: React.FC<{ navigateTo: (page: string, loanId?: string) => void }> = ({ navigateTo }) => {
  const { user } = useAuth();
  const [stats, setStats] = useState<LenderStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    const fetchDashboardData = async () => {
      setLoading(true);
      const allLoans = await getLoans();
      const lenderLoans = allLoans.filter(loan => loan.lenderId === user.id);

      const activeLoansCount = lenderLoans.filter(l => l.status === 'Disbursed' || l.status === 'Overdue').length;
      const totalDisbursed = lenderLoans.reduce((sum, l) => sum + (l.amountApproved || 0), 0);
      
      // This is a simplified calculation. A real app would sum actual repayments.
      const totalRepaid = lenderLoans
        .filter(l => l.status === 'Paid')
        .reduce((sum, l) => sum + (l.amountApproved || 0), 0);

      const statusCounts = lenderLoans.reduce((acc, loan) => {
          const status = loan.status;
          acc[status] = (acc[status] || 0) + 1;
          return acc;
      }, {} as {[key: string]: number});
      
      const statusDistribution = Object.entries(statusCounts).map(([name, value]) => ({name, value}));

      setStats({ activeLoansCount, totalDisbursed, totalRepaid, statusDistribution });
      setLoading(false);
    };

    fetchDashboardData();
  }, [user]);

  if (loading || !stats) {
    return (
      <div className="flex justify-center items-center h-full">
        <LoadingSpinner size={48} />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold tracking-tight">Lender Dashboard</h1>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Disbursed</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(stats.totalDisbursed)}</div>
            <p className="text-xs text-muted-foreground">Total capital deployed.</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Loans</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.activeLoansCount}</div>
            <p className="text-xs text-muted-foreground">Number of loans currently being repaid.</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Repaid</CardTitle>
            <PiggyBank className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(stats.totalRepaid)}</div>
            <p className="text-xs text-muted-foreground">Based on fully paid loans.</p>
          </CardContent>
        </Card>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <div className="col-span-full lg:col-span-4">
          <LoanList title="My Loan Portfolio" filter={{ lenderId: user?.id }} navigateTo={navigateTo} />
        </div>
        <Card className="col-span-full lg:col-span-3">
            <CardHeader>
                <CardTitle>Loan Status Distribution</CardTitle>
                <CardDescription>A breakdown of your loan portfolio by status.</CardDescription>
            </CardHeader>
            <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                        <Pie
                            data={stats.statusDistribution}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={100}
                            fill="#8884d8"
                            dataKey="value"
                            nameKey="name"
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        >
                            {stats.statusDistribution.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[entry.name as keyof typeof COLORS] || '#cccccc'} />
                            ))}
                        </Pie>
                        <Tooltip formatter={(value: number, name: string) => [`${value} loans`, name]} />
                        <Legend />
                    </PieChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default LenderDashboard;
