
import React, { useEffect, useState } from 'react';
import { getLoans } from '../../services/firebaseService';
import { Loan, LoanStatus, RepaymentScheduleItem } from '../../types';
import { useAuth } from '../../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../ui/Card';
import LoadingSpinner from '../shared/LoadingSpinner';
import { formatCurrency, formatDate, getStatusColor, cn } from '../../lib/utils';
import { Button } from '../ui/Button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/Table';
import { Badge } from '../ui/Badge';
import { HandCoins, CalendarClock, Receipt, Hourglass } from 'lucide-react';


const BorrowerDashboard: React.FC<{ navigateTo: (page: string) => void }> = ({ navigateTo }) => {
  const { user } = useAuth();
  const [loans, setLoans] = useState<Loan[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeLoan, setActiveLoan] = useState<Loan | null>(null);
  const [nextPayment, setNextPayment] = useState<RepaymentScheduleItem | null>(null);

  useEffect(() => {
    if (!user) return;

    const fetchBorrowerData = async () => {
      setLoading(true);
      const allLoans = await getLoans();
      const borrowerLoans = allLoans
        .filter(loan => loan.borrowerId === user.id)
        .sort((a,b) => new Date(b.applicationDate).getTime() - new Date(a.applicationDate).getTime());
        
      setLoans(borrowerLoans);

      const currentActiveLoan = borrowerLoans.find(l => l.status === LoanStatus.Disbursed || l.status === LoanStatus.Overdue) || null;
      setActiveLoan(currentActiveLoan);
      
      if(currentActiveLoan && currentActiveLoan.repaymentSchedule) {
        const upcomingPayment = currentActiveLoan.repaymentSchedule.find(p => p.status === 'Pending') || null;
        setNextPayment(upcomingPayment);
      }
      
      setLoading(false);
    };

    fetchBorrowerData();
  }, [user]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full">
        <LoadingSpinner size={48} />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Borrower Dashboard</h1>
        <Button onClick={() => navigateTo('apply-loan')}>
            <HandCoins className="mr-2 h-4 w-4" /> Apply for New Loan
        </Button>
      </div>

      {activeLoan ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Active Loan Amount</CardTitle>
                    <Receipt className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{formatCurrency(activeLoan.amountApproved)}</div>
                    <p className="text-xs text-muted-foreground">{activeLoan.purpose}</p>
                </CardContent>
            </Card>
            <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Next Payment Due</CardTitle>
                    <CalendarClock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{nextPayment ? formatDate(nextPayment.dueDate) : 'N/A'}</div>
                    <p className="text-xs text-muted-foreground">Amount: {formatCurrency(nextPayment?.amountDue)}</p>
                </CardContent>
            </Card>
             <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Interest Rate</CardTitle>
                    <Hourglass className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{activeLoan.interestRate?.toFixed(2)}%</div>
                    <p className="text-xs text-muted-foreground">{activeLoan.repaymentPeriod} months term</p>
                </CardContent>
            </Card>
        </div>
      ) : (
        <Card className="text-center py-12">
            <CardContent>
                <h3 className="text-xl font-semibold">No Active Loans</h3>
                <p className="text-muted-foreground mt-2">You do not have any active loans right now.</p>
            </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>My Loan History</CardTitle>
          <CardDescription>A list of all your past and present loan applications.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Purpose</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loans.length > 0 ? loans.map(loan => (
                <TableRow key={loan.id}>
                  <TableCell>{formatDate(loan.applicationDate)}</TableCell>
                  <TableCell>{formatCurrency(loan.amountRequested)}</TableCell>
                  <TableCell>{loan.purpose}</TableCell>
                  <TableCell>
                    <Badge className={cn('font-semibold', getStatusColor(loan.status))}>{loan.status}</Badge>
                  </TableCell>
                </TableRow>
              )) : (
                <TableRow>
                    <TableCell colSpan={4} className="text-center">No loan applications found.</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default BorrowerDashboard;
