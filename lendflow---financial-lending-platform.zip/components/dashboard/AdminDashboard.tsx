
import React, { useEffect, useState } from 'react';
import { getLoans } from '../../services/firebaseService';
import { Loan, LoanStatus } from '../../types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../ui/Card';
import LoadingSpinner from '../shared/LoadingSpinner';
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid } from 'recharts';
import { formatCurrency } from '../../lib/utils';
import { Button } from '../ui/Button';
import LoanList from '../loans/LoanList';
import { DollarSign, FileText, CheckCircle, Clock } from 'lucide-react';

interface DashboardStats {
  totalLoanValue: number;
  pendingApplications: number;
  approvedLoans: number;
  paidLoans: number;
  monthlyData: { name: string; value: number }[];
}

const AdminDashboard: React.FC<{ navigateTo: (page: string) => void }> = ({ navigateTo }) => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      setLoading(true);
      const loans = await getLoans();
      const totalLoanValue = loans
        .filter(l => l.status === LoanStatus.Disbursed || l.status === LoanStatus.Paid)
        .reduce((sum, l) => sum + (l.amountApproved || 0), 0);

      const pendingApplications = loans.filter(l => l.status === LoanStatus.Pending).length;
      const approvedLoans = loans.filter(l => l.status === LoanStatus.Approved || l.status === LoanStatus.Disbursed).length;
      const paidLoans = loans.filter(l => l.status === LoanStatus.Paid).length;
      
      const monthlyData: { [key: string]: number } = {};
      loans.forEach(loan => {
          if(loan.amountApproved){
              const month = new Date(loan.applicationDate).toLocaleString('default', { month: 'short', year: '2-digit' });
              if (!monthlyData[month]) {
                monthlyData[month] = 0;
              }
              monthlyData[month] += loan.amountApproved;
          }
      });
      
      const chartData = Object.entries(monthlyData)
        .map(([name, value]) => ({ name, value }))
        .sort((a,b) => new Date(a.name) > new Date(b.name) ? 1 : -1);


      setStats({ totalLoanValue, pendingApplications, approvedLoans, paidLoans, monthlyData: chartData });
      setLoading(false);
    };

    fetchDashboardData();
  }, []);

  if (loading || !stats) {
    return (
      <div className="flex justify-center items-center h-full">
        <LoadingSpinner size={48} />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold tracking-tight">Admin Dashboard</h1>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Loan Value</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(stats.totalLoanValue)}</div>
            <p className="text-xs text-muted-foreground">Total value of all disbursed loans</p>
          </CardContent>
        </Card>
         <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Applications</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pendingApplications}</div>
            <p className="text-xs text-muted-foreground">Loans awaiting review</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Loans</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.approvedLoans}</div>
            <p className="text-xs text-muted-foreground">Approved or disbursed loans</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed Loans</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.paidLoans}</div>
            <p className="text-xs text-muted-foreground">Fully repaid loans</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
            <CardHeader>
                <CardTitle>Loan Volume Overview</CardTitle>
                <CardDescription>Value of loans approved per month.</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
                <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={stats.monthlyData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false}/>
                        <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value/1000}k`}/>
                        <Tooltip formatter={(value: number) => formatCurrency(value)} />
                        <Legend />
                        <Bar dataKey="value" name="Loan Value" fill="#1e3a8a" radius={[4, 4, 0, 0]} />
                    </BarChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
        <div className="col-span-4 lg:col-span-3">
             <LoanList title="Pending Applications" filter={{ status: LoanStatus.Pending }} navigateTo={navigateTo}/>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
