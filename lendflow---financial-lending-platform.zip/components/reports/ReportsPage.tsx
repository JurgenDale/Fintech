
import React, { useEffect, useState } from 'react';
import { getLoans } from '../../services/firebaseService';
import { Loan, LoanStatus } from '../../types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../ui/Card';
import LoadingSpinner from '../shared/LoadingSpinner';
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid } from 'recharts';
import { formatCurrency } from '../../lib/utils';

interface ReportData {
  statusDistribution: { name: string; value: number }[];
  purposeDistribution: { name: string; value: number }[];
  averageLoanAmount: number;
  averageInterestRate: number;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#AF19FF', '#FF4560'];

const ReportsPage: React.FC = () => {
  const [reportData, setReportData] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchReportData = async () => {
      setLoading(true);
      const loans = await getLoans();
      
      const approvedLoans = loans.filter(l => l.status === LoanStatus.Approved || l.status === LoanStatus.Disbursed || l.status === LoanStatus.Paid);

      // Status Distribution
      const statusCounts = loans.reduce((acc, loan) => {
        acc[loan.status] = (acc[loan.status] || 0) + 1;
        return acc;
      }, {} as { [key: string]: number });
      const statusDistribution = Object.entries(statusCounts).map(([name, value]) => ({ name, value }));
      
      // Purpose Distribution
      const purposeCounts = approvedLoans.reduce((acc, loan) => {
        acc[loan.purpose] = (acc[loan.purpose] || 0) + (loan.amountApproved || 0);
        return acc;
      }, {} as { [key: string]: number });
      const purposeDistribution = Object.entries(purposeCounts).map(([name, value]) => ({ name, value }));

      // Averages
      const totalAmount = approvedLoans.reduce((sum, l) => sum + (l.amountApproved || 0), 0);
      const averageLoanAmount = approvedLoans.length > 0 ? totalAmount / approvedLoans.length : 0;
      
      const totalInterest = approvedLoans.reduce((sum, l) => sum + (l.interestRate || 0), 0);
      const averageInterestRate = approvedLoans.length > 0 ? totalInterest / approvedLoans.length : 0;

      setReportData({ statusDistribution, purposeDistribution, averageLoanAmount, averageInterestRate });
      setLoading(false);
    };

    fetchReportData();
  }, []);

  if (loading || !reportData) {
    return <div className="flex justify-center items-center h-full"><LoadingSpinner size={48} /></div>;
  }

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold tracking-tight">Financial Reports</h1>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Average Loan Amount</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{formatCurrency(reportData.averageLoanAmount)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Average Interest Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{reportData.averageInterestRate.toFixed(2)}%</p>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Loan Status Distribution</CardTitle>
            <CardDescription>Number of loans across all statuses.</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={reportData.statusDistribution} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" hide />
                <YAxis type="category" dataKey="name" width={80} stroke="#888888" fontSize={12} />
                <Tooltip formatter={(value: number) => [`${value} loans`]} />
                <Bar dataKey="value" name="Count" fill="#1e3a8a" background={{ fill: '#eee' }} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Loan Value by Purpose</CardTitle>
            <CardDescription>Total value of approved loans by purpose.</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={reportData.purposeDistribution} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} fill="#8884d8">
                  {reportData.purposeDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => formatCurrency(value)} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ReportsPage;
