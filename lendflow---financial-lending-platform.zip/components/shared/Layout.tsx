import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '../ui/Button';
import { Home, LogOut, Landmark, FileText, HandCoins, BarChart2 } from 'lucide-react';
import { Role } from '../../types';

export const Layout: React.FC<{ children: React.ReactNode; navigateTo: (page: string) => void; }> = ({ children, navigateTo }) => {
  const { user, logout } = useAuth();
  const currentYear = new Date().getFullYear();

  const navItems = {
    [Role.Admin]: [
      { icon: Home, label: 'Dashboard', page: 'dashboard' },
      { icon: FileText, label: 'All Loans', page: 'all-loans' },
      { icon: BarChart2, label: 'Reports', page: 'reports' },
    ],
    [Role.Lender]: [
      { icon: Home, label: 'Dashboard', page: 'dashboard' },
    ],
    [Role.Borrower]: [
      { icon: Home, label: 'Dashboard', page: 'dashboard' },
      { icon: HandCoins, label: 'Apply for Loan', page: 'apply-loan' },
    ],
  };

  return (
    <div className="flex min-h-screen w-full flex-col bg-muted/40">
      <aside className="fixed inset-y-0 left-0 z-10 hidden w-60 flex-col border-r bg-background sm:flex">
        <div className="flex h-16 items-center border-b px-6">
          <a href="#" className="flex items-center gap-2 font-semibold">
            <Landmark className="h-6 w-6 text-primary" />
            <span className="">LendFlow</span>
          </a>
        </div>
        <nav className="flex-1 overflow-auto py-4">
          <ul className="grid items-start px-4 text-sm font-medium">
            {user && navItems[user.role].map(item => (
                <li key={item.page}>
                    <button
                        onClick={() => navigateTo(item.page)}
                        className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary hover:bg-muted"
                    >
                        <item.icon className="h-4 w-4" />
                        {item.label}
                    </button>
                </li>
            ))}
          </ul>
        </nav>
      </aside>

      <div className="flex flex-1 flex-col sm:gap-4 sm:py-4 sm:pl-60">
        <header className="sticky top-0 z-30 flex h-14 items-center gap-4 border-b bg-background px-4 sm:static sm:h-auto sm:border-0 sm:bg-transparent sm:px-6">
          <div className="ml-auto flex items-center gap-4">
            <span className="text-sm text-muted-foreground">
              Welcome, <span className="font-semibold text-primary">{user?.name}</span> ({user?.role})
            </span>
            <Button variant="outline" size="sm" onClick={logout}>
              <LogOut className="h-4 w-4 mr-2"/>
              Switch User
            </Button>
          </div>
        </header>

        <main className="grid flex-1 items-start gap-4 p-4 sm:px-6 sm:py-0 md:gap-8">
          {children}
        </main>

        <footer className="text-center p-4 text-xs text-muted-foreground">
          © {currentYear} Finsuite. Developed by Hezdev AI a Grosspay Digital Company.
        </footer>
      </div>
    </div>
  );
};
