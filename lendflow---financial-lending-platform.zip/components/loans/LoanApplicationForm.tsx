
import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { addLoan } from '../../services/firebaseService';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/Card';
import LoadingSpinner from '../shared/LoadingSpinner';

const LoanApplicationForm: React.FC<{ onApplicationSuccess: () => void }> = ({ onApplicationSuccess }) => {
  const { user } = useAuth();
  const [amount, setAmount] = useState('');
  const [purpose, setPurpose] = useState('');
  const [period, setPeriod] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || user.role !== 'Borrower') {
      setError('Only borrowers can apply for loans.');
      return;
    }
    if (!amount || !purpose || !period) {
      setError('All fields are required.');
      return;
    }
    setError('');
    setIsLoading(true);

    try {
      await addLoan({
        borrowerId: user.id,
        amountRequested: parseFloat(amount),
        purpose,
        repaymentPeriod: parseInt(period, 10),
      }, user);
      onApplicationSuccess();
    } catch (err) {
      setError('Failed to submit application. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>New Loan Application</CardTitle>
        <CardDescription>Fill out the form below to apply for a new loan.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-1">
              Loan Amount Requested ($)
            </label>
            <Input
              id="amount"
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="e.g., 5000"
              required
            />
          </div>
          <div>
            <label htmlFor="purpose" className="block text-sm font-medium text-gray-700 mb-1">
              Loan Purpose
            </label>
            <Input
              id="purpose"
              type="text"
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
              placeholder="e.g., Home Renovation"
              required
            />
          </div>
          <div>
            <label htmlFor="period" className="block text-sm font-medium text-gray-700 mb-1">
              Desired Repayment Period (Months)
            </label>
            <Input
              id="period"
              type="number"
              value={period}
              onChange={(e) => setPeriod(e.target.value)}
              placeholder="e.g., 12"
              required
            />
          </div>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <div className="flex justify-end pt-2">
            <Button type="submit" disabled={isLoading}>
              {isLoading && <LoadingSpinner size={16} className="mr-2" />}
              {isLoading ? 'Submitting...' : 'Submit Application'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default LoanApplicationForm;
