
import React, { useState } from 'react';
import { Loan, LoanStatus } from '../../types';
import { updateLoan } from '../../services/firebaseService';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../ui/Dialog';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import LoadingSpinner from '../shared/LoadingSpinner';
import { formatCurrency, formatDate } from '../../lib/utils';

interface LoanApprovalModalProps {
  loan: Loan;
  onClose: () => void;
  onSuccess: () => void;
}

const LoanApprovalModal: React.FC<LoanApprovalModalProps> = ({ loan, onClose, onSuccess }) => {
  const [interestRate, setInterestRate] = useState('5');
  const [amountApproved, setAmountApproved] = useState(loan.amountRequested.toString());
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleAction = async (status: LoanStatus.Approved | LoanStatus.Rejected) => {
    setError('');
    setIsLoading(true);
    try {
        let updates: Partial<Loan> = { status, approvalDate: new Date().toISOString() };
        if (status === LoanStatus.Approved) {
            if (!interestRate || !amountApproved) {
                setError("Interest rate and approved amount are required for approval.");
                setIsLoading(false);
                return;
            }
            updates = {
                ...updates,
                interestRate: parseFloat(interestRate),
                amountApproved: parseFloat(amountApproved),
            };
        }
      await updateLoan(loan.id, updates);
      onSuccess();
    } catch (err) {
      setError(`Failed to ${status === LoanStatus.Approved ? 'approve' : 'reject'} loan. Please try again.`);
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
        <DialogHeader>
            <DialogTitle>Review Loan Application</DialogTitle>
            <DialogDescription>Review the details below and approve or reject the application.</DialogDescription>
        </DialogHeader>
        <DialogContent>
            <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                    <div><p className="font-medium text-sm">Borrower:</p><p>{loan.borrowerName}</p></div>
                    <div><p className="font-medium text-sm">Application Date:</p><p>{formatDate(loan.applicationDate)}</p></div>
                    <div><p className="font-medium text-sm">Amount Requested:</p><p>{formatCurrency(loan.amountRequested)}</p></div>
                    <div><p className="font-medium text-sm">Purpose:</p><p>{loan.purpose}</p></div>
                </div>
                 <hr/>
                <div className="space-y-4">
                     <p className="font-medium text-sm">Approval Details</p>
                    <div>
                        <label htmlFor="amountApproved" className="block text-sm font-medium text-gray-700 mb-1">Amount to Approve ($)</label>
                        <Input id="amountApproved" type="number" value={amountApproved} onChange={e => setAmountApproved(e.target.value)} />
                    </div>
                    <div>
                        <label htmlFor="interestRate" className="block text-sm font-medium text-gray-700 mb-1">Interest Rate (%)</label>
                        <Input id="interestRate" type="number" value={interestRate} onChange={e => setInterestRate(e.target.value)} />
                    </div>
                </div>
                {error && <p className="text-sm text-red-600">{error}</p>}
            </div>
        </DialogContent>
        <DialogFooter>
            <Button variant="outline" onClick={onClose} disabled={isLoading}>Cancel</Button>
            <Button variant="destructive" onClick={() => handleAction(LoanStatus.Rejected)} disabled={isLoading}>
                {isLoading ? <LoadingSpinner size={16} /> : 'Reject'}
            </Button>
            <Button onClick={() => handleAction(LoanStatus.Approved)} disabled={isLoading}>
                {isLoading ? <LoadingSpinner size={16} className="mr-2" /> : 'Approve Loan'}
            </Button>
        </DialogFooter>
    </Dialog>
  );
};

export default LoanApprovalModal;
