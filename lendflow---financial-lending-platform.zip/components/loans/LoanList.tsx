
import React, { useEffect, useState } from 'react';
import { getLoans, updateLoan } from '../../services/firebaseService';
import { Loan, LoanStatus } from '../../types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../ui/Card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/Table';
import LoadingSpinner from '../shared/LoadingSpinner';
import { formatCurrency, formatDate, getStatusColor, cn } from '../../lib/utils';
import { Button } from '../ui/Button';
import { useAuth } from '../../contexts/AuthContext';
import LoanApprovalModal from './LoanApprovalModal';
import { Badge } from '../ui/Badge';

interface LoanListProps {
  title: string;
  filter: Partial<Loan>;
  navigateTo: (page: string, loanId?: string) => void;
}

const LoanList: React.FC<LoanListProps> = ({ title, filter }) => {
  const { user } = useAuth();
  const [loans, setLoans] = useState<Loan[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [approvingLoan, setApprovingLoan] = useState<Loan | null>(null);

  const fetchLoans = async () => {
    setLoading(true);
    try {
      const allLoans = await getLoans();
      let filteredLoans = allLoans.filter(loan => {
        return Object.entries(filter).every(([key, value]) => loan[key as keyof Loan] === value);
      });
      // Further filter for lender/borrower specific views
      if(user?.role === 'Lender') {
        filteredLoans = filteredLoans.filter(loan => loan.lenderId === user.id || loan.status === 'Approved');
      } else if(user?.role === 'Borrower') {
        filteredLoans = filteredLoans.filter(loan => loan.borrowerId === user.id);
      }

      setLoans(filteredLoans.sort((a, b) => new Date(b.applicationDate).getTime() - new Date(a.applicationDate).getTime()));
    } catch (err) {
      setError('Failed to fetch loans.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLoans();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(filter), user?.id]);

  const handleApprovalSuccess = () => {
    setApprovingLoan(null);
    fetchLoans(); // Refresh the list
  };
  
  const handleDisburse = async (loanId: string) => {
    try {
        await updateLoan(loanId, { status: LoanStatus.Disbursed, disbursementDate: new Date().toISOString() });
        fetchLoans();
    } catch (error) {
        console.error("Failed to disburse loan", error);
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <LoadingSpinner size={32} />
      </div>
    );
  }

  if (error) {
    return <p className="text-center text-red-500">{error}</p>;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>A list of loans matching the criteria.</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Borrower</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Purpose</TableHead>
              <TableHead>Date Applied</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loans.length > 0 ? (
              loans.map((loan) => (
                <TableRow key={loan.id}>
                  <TableCell className="font-medium">{loan.borrowerName}</TableCell>
                  <TableCell>{formatCurrency(loan.amountRequested)}</TableCell>
                  <TableCell>{loan.purpose}</TableCell>
                  <TableCell>{formatDate(loan.applicationDate)}</TableCell>
                  <TableCell>
                    <Badge className={cn('font-semibold', getStatusColor(loan.status))}>{loan.status}</Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    {user?.role === 'Admin' && loan.status === 'Pending' && (
                        <Button variant="outline" size="sm" onClick={() => setApprovingLoan(loan)}>
                            Review
                        </Button>
                    )}
                    {user?.role === 'Admin' && loan.status === 'Approved' && (
                        <Button variant="default" size="sm" onClick={() => handleDisburse(loan.id)}>
                            Disburse
                        </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} className="text-center">
                  No loans found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
       {approvingLoan && (
        <LoanApprovalModal
          loan={approvingLoan}
          onClose={() => setApprovingLoan(null)}
          onSuccess={handleApprovalSuccess}
        />
      )}
    </Card>
  );
};

export default LoanList;
